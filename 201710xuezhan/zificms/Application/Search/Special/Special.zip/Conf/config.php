<?php

// +----------------------------------------------------------------------
// | ShuipFCMS 配置
// +----------------------------------------------------------------------
// | Copyright (c) 2012-2014 http://www.shuipfcms.com, All rights reserved.
// +----------------------------------------------------------------------
// | Author: 水平凡 <admin@abc3210.com>
// +----------------------------------------------------------------------
return array(
    'COMPONENTS' => array(
        'SpecialUrl' => array(
            'class' => '\\Special\\ORG\\SpecialUrl',
            'path' => 'Special.ORG.SpecialUrl',
        ),
        'SpecialHtml' => array(
            'class' => '\\Special\\ORG\\SpecialHtml',
            'path' => 'Special.ORG.SpecialHtml',
        ),
    ),
);
