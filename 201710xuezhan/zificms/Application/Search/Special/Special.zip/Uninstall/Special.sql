DROP TABLE IF EXISTS `shuipfcms_special`;
DROP TABLE IF EXISTS `lvyecms_special`;
DROP TABLE IF EXISTS `shuipfcms_special_content`;
DROP TABLE IF EXISTS `lvyecms_special_content`;
DROP TABLE IF EXISTS `shuipfcms_special_type`;
DROP TABLE IF EXISTS `lvyecms_special_type`;