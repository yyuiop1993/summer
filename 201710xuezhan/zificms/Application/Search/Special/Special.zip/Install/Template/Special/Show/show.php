<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>{$title} - {$special.title}</title>
</head>
<body>
专题内容页模板<br/>
当前信息名称：{$title}<br/>
当前信息地址：{$url}<br/>
当前专题名称：{$special.title}<br/>
当前专题地址：{$special.url}<br/>
<hr />
文章内容：{$content}<br/>
</body>
</html>