	<!-- footer start -->
	<div class="footer clearfix min-w">
		<div class="w">
			<div class="govlogo fl"><a href="#"></a></div>
			<div class="copyright fl">
				{:cache('Config.footerinfo')}
			</div>
			<div class="findwrong fr"><a href="#"></a></div>
		</div>
	</div>
	<!-- footer end -->
	<script type="text/javascript" src="{$config_siteurl}statics/default/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="{$config_siteurl}statics/default/js/base.js"></script>
	<link rel="stylesheet" href="{$config_siteurl}statics/default/js/index.js">
	<script type="text/javascript">
		tick();
	</script>
</body>
</html>