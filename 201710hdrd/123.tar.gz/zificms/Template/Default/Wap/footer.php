		<div class="w">
			<div class="footer_left">
				<div class="copyright">
					{:cache('Config.wap_powby')}
					<br/>
					技术支持：<a href="http://www.zhifengchina.cn" target="_blank">智峰软件</a>
				</div>
			</div>
			<div class="footer_right">
				<img src="{$config_siteurl}statics/default/wap/images/ewm.jpg" alt="微信公众号" title="微信公众号">
			</div>
		</div>

<script type="text/javascript" src="{$config_siteurl}statics/default/wap/js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="{$config_siteurl}statics/default/wap/js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="{$config_siteurl}statics/default/wap/js/base.js"></script>