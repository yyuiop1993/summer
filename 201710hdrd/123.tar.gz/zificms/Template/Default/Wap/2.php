<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
 <div style="width:100%; height:auto; background:#000; line-height:30px">
	<a href="{:U('Wap/Index/index')}">手机版</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="{:Cache('Config.siteurl')}">访问电脑版</a>
</div>
 
 
</body>
</html>