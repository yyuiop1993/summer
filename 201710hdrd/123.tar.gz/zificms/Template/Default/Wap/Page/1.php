<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<template file="Wap/header.php"/>
<div style="width:100%; height:200px; background:#F9C">
标题：{$title}<br/>
关键字：{$keywords}<br/>
内容：{$content}<br/>
<template file="Wap/footer.php"/>