<?php if (!defined('THINK_PATH')) exit(); if (!defined('SHUIPF_VERSION')) exit(); ?>
<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>系统后台 - <?php echo ($Config["sitename"]); ?> - by LvyeCMS</title>
<?php if (!defined('SHUIPF_VERSION')) exit(); ?><link href="<?php echo ($config_siteurl); ?>statics/css/admin_style.css" rel="stylesheet" />
<link href="<?php echo ($config_siteurl); ?>statics/js/artDialog/skins/default.css" rel="stylesheet" />
<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<script type="text/javascript">
//全局变量
var GV = {
    DIMAUB: "<?php echo ($config_siteurl); ?>",
	JS_ROOT: "<?php echo ($config_siteurl); ?>statics/js/"
};
</script>
<script src="<?php echo ($config_siteurl); ?>statics/js/wind.js"></script>
<script src="<?php echo ($config_siteurl); ?>statics/js/jquery.js"></script>
</head>
<body>
<div class="wrap J_check_wrap">
  <?php  $getMenu = isset($Custom)?$Custom:D('Admin/Menu')->getMenu(); if($getMenu) { ?>
<div class="nav">
  <?php
 if(!empty($menuReturn)){ echo '<div class="return"><a href="'.$menuReturn['url'].'">'.$menuReturn['name'].'</a></div>'; } ?>
  <ul class="cc">
    <?php
 foreach($getMenu as $r){ $app = $r['app']; $controller = $r['controller']; $action = $r['action']; ?>
    <li <?php echo $action==ACTION_NAME ?'class="current"':""; ?>><a href="<?php echo U("".$app."/".$controller."/".$action."",$r['parameter']);?>" <?php echo $r['target']?'target="'.$r['target'].'"':"" ?>><?php echo $r['name'];?></a></li>
    <?php
 } ?>
  </ul>
</div>
<?php } ?>
  <div class="h_a">说明</div>
  <div class="prompt_text">
    <ul>
      <li>模块管理可以很好的扩展网站运营中所需功能！</li>
      <li><font color="#FF0000">获取更多模块请到官方网站模块扩展中下载安装！安装非官方发表模块需谨慎，有被清空数据库的危险！</font></li>
      <li>官网地址：<font color="#FF0000">http://www.lvyecms.com</font>，<a href="http://www.lvyecms.com" target="_blank">立即前往</a>！</li>
    </ul>
  </div>
  <div class="table_list">
    <table width="100%">
      <colgroup>
      <col width="90">
      <col>
      <col width="160">
      </colgroup>
      <thead>
        <tr>
          <td align="center">应用图标</td>
          <td>应用介绍</td>
          <td align="center">安装时间</td>
          <td align="center">操作</td>
        </tr>
      </thead>
      <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
        <td>
            <div class="app_icon">
            <?php if( $vo['icon'] ): ?><img src="<?php echo ($vo["icon"]); ?>" alt="<?php echo ($vo["modulename"]); ?>" width="80" height="80">
            <?php else: ?>
            <img src="<?php echo ($config_siteurl); ?>statics/images/modul.png" alt="<?php echo ($vo["modulename"]); ?>" width="80" height="80"><?php endif; ?>
            </div>
        </td>
        <td valign="top">
            <h3 class="mb5 f12"><?php if( $vo['address'] ): ?><a target="_blank" href="<?php echo ($vo["address"]); ?>"><?php echo ($vo["modulename"]); ?></a><?php else: echo ($vo["modulename"]); endif; ?></h3>
            <div class="mb5"> <span class="mr15">版本：<b><?php echo ($vo["version"]); ?></b></span> <span>开发者：<?php if( $vo['author'] ): ?><a target="_blank" href="<?php echo ($vo["authorsite"]); ?>"><?php echo ($vo["author"]); ?></a><?php else: ?>匿名开发者<?php endif; ?></span> <span>适配 LvyeCMS 最低版本：<?php if( $vo['adaptation'] ): echo ($vo["adaptation"]); else: ?><font color="#FF0000">没有标注，可能存在兼容风险</font><?php endif; ?></span> </div>
            <div class="gray"><?php if( $vo['introduce'] ): echo ($vo["introduce"]); else: ?>没有任何介绍<?php endif; ?></div>
            <div> <span class="mr20"><a href="<?php echo ($vo["authorsite"]); ?>" target="_blank"><?php echo ($vo["authorsite"]); ?></a></span> </div>
        </td>
        <td align="center"><?php if( $vo['installtime'] ): ?><span><?php echo (date('Y-m-d H:i:s',$vo["installtime"])); ?></span><?php else: ?>/<?php endif; ?></td>
        <td align="center">
          <?php
 $op = array(); if(empty($vo['installtime'])){ $op[] = '<a href="'.U('install',array('module'=>$vo['module'])).'" class="btn btn_submit mr5">安装</a>'; }else{ if($vo['iscore'] == 0){ $op[] = '<a href="'.U('uninstall',array('module'=>$vo['module'])).'" class="J_ajax_del btn" data-msg="确定要卸载吗？<br/>注意：卸载模块后会删除对应模块目录！">卸载</a>'; } if($vo['disabled']){ if($vo['iscore'] == 0){ $op[] = '<a href="'.U('disabled',array('module'=>$vo['module'])).'" class="btn mr5">禁用</a>'; } }else{ $op[] = '<a href="'.U('disabled',array('module'=>$vo['module'])).'" class="btn btn_submit  mr5">启用</a>'; } } echo implode('  ',$op); ?>
        </td>
      </tr><?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
  </div>
  <div class="p10">
        <div class="pages"><?php echo ($Page); ?></div>
   </div>
</div>
<script src="<?php echo ($config_siteurl); ?>statics/js/common.js"></script>
</body>
</html>