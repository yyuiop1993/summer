<?php if (!defined('THINK_PATH')) exit(); if (!defined('SHUIPF_VERSION')) exit(); ?>
<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>系统后台 - <?php echo ($Config["sitename"]); ?> - by LvyeCMS</title>
<?php if (!defined('SHUIPF_VERSION')) exit(); ?><link href="<?php echo ($config_siteurl); ?>statics/css/admin_style.css" rel="stylesheet" />
<link href="<?php echo ($config_siteurl); ?>statics/js/artDialog/skins/default.css" rel="stylesheet" />
<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<script type="text/javascript">
//全局变量
var GV = {
    DIMAUB: "<?php echo ($config_siteurl); ?>",
	JS_ROOT: "<?php echo ($config_siteurl); ?>statics/js/"
};
</script>
<script src="<?php echo ($config_siteurl); ?>statics/js/wind.js"></script>
<script src="<?php echo ($config_siteurl); ?>statics/js/jquery.js"></script>
</head>
<body class="J_scroll_fixed">
<div class="wrap J_check_wrap">
  <?php  $getMenu = isset($Custom)?$Custom:D('Admin/Menu')->getMenu(); if($getMenu) { ?>
<div class="nav">
  <?php
 if(!empty($menuReturn)){ echo '<div class="return"><a href="'.$menuReturn['url'].'">'.$menuReturn['name'].'</a></div>'; } ?>
  <ul class="cc">
    <?php
 foreach($getMenu as $r){ $app = $r['app']; $controller = $r['controller']; $action = $r['action']; ?>
    <li <?php echo $action==ACTION_NAME ?'class="current"':""; ?>><a href="<?php echo U("".$app."/".$controller."/".$action."",$r['parameter']);?>" <?php echo $r['target']?'target="'.$r['target'].'"':"" ?>><?php echo $r['name'];?></a></li>
    <?php
 } ?>
  </ul>
</div>
<?php } ?>
  <form action="<?php echo U("Rbac/setting_cat_priv");?>" method="post" class="J_ajaxForm">
    <div class="h_a">栏目权限</div>
    <div class="table_full"> 
    <table width="100%">
        <tr>
          <th width="50" align="center"><label>全选<input type="checkbox" onclick="select_all(0, this)"></label></th>
          <th align="left">栏目名称</th>
          <th width="35" align="center">查看</th>
          <th width="35" align="center">添加</th>
          <th width="35" align="center">修改</th>
          <th width="35" align="center">删除</th>
          <th width="35" align="center">排序</th>
          <th width="35" align="center">推送</th>
          <th width="35" align="center">移动</th>
        </tr>
      <?php echo ($categorys); ?>
    </table>
    </div>
    <div class="btn_wrap">
      <div class="btn_wrap_pd">
        <input type="hidden" name="roleid" value="<?php echo ($roleid); ?>" />
        <button class="btn btn_submit mr10 J_ajax_submit_btn" type="submit">提交</button>
      </div>
    </div>
  </form>
</div>
<script src="<?php echo ($config_siteurl); ?>statics/js/common.js?v"></script>
<script type="text/javascript">
function select_all(name, obj) {
    if (obj.checked) {
        if (name == 0) {
			$.each($("input[type='checkbox']"),function(i,rs){
				if($(this).attr('disabled') != 'disabled'){
					$(this).attr('checked', 'checked');
				}
			});
            //$("input[type='checkbox']").attr('checked', 'checked');
        } else {
			$.each($("input[type='checkbox'][name='priv[" + name + "][]']"),function(i,rs){
				if($(this).attr('disabled') != 'disabled'){
					$(this).attr('checked', 'checked');
				}
			});
            //$("input[type='checkbox'][name='priv[" + name + "][]']").attr('checked', 'checked');
        }
    } else {
        if (name == 0) {
            $("input[type='checkbox']").attr('checked', null);
        } else {
            $("input[type='checkbox'][name='priv[" + name + "][]']").attr('checked', null);
        }
    }
}
</script>
</body>
</html>