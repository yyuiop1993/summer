<?php if (!defined('THINK_PATH')) exit(); if (!defined('SHUIPF_VERSION')) exit(); ?>
<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>系统后台 - <?php echo ($Config["sitename"]); ?> - by LvyeCMS</title>
<?php if (!defined('SHUIPF_VERSION')) exit(); ?><link href="<?php echo ($config_siteurl); ?>statics/css/admin_style.css" rel="stylesheet" />
<link href="<?php echo ($config_siteurl); ?>statics/js/artDialog/skins/default.css" rel="stylesheet" />
<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<script type="text/javascript">
//全局变量
var GV = {
    DIMAUB: "<?php echo ($config_siteurl); ?>",
	JS_ROOT: "<?php echo ($config_siteurl); ?>statics/js/"
};
</script>
<script src="<?php echo ($config_siteurl); ?>statics/js/wind.js"></script>
<script src="<?php echo ($config_siteurl); ?>statics/js/jquery.js"></script>
</head>
<body>
<div class="wrap J_check_wrap">
  <?php  $getMenu = isset($Custom)?$Custom:D('Admin/Menu')->getMenu(); if($getMenu) { ?>
<div class="nav">
  <?php
 if(!empty($menuReturn)){ echo '<div class="return"><a href="'.$menuReturn['url'].'">'.$menuReturn['name'].'</a></div>'; } ?>
  <ul class="cc">
    <?php
 foreach($getMenu as $r){ $app = $r['app']; $controller = $r['controller']; $action = $r['action']; ?>
    <li <?php echo $action==ACTION_NAME ?'class="current"':""; ?>><a href="<?php echo U("".$app."/".$controller."/".$action."",$r['parameter']);?>" <?php echo $r['target']?'target="'.$r['target'].'"':"" ?>><?php echo $r['name'];?></a></li>
    <?php
 } ?>
  </ul>
</div>
<?php } ?>
  <div class="h_a">说明</div>
  <div class="prompt_text">
    <ul>
      <li>插件管理可以很好的扩展网站运营中所需功能！</li>
      <li><font color="#FF0000">获取更多插件请到官方网站插件扩展中下载安装！安装非官方发表插件需谨慎，有被清空数据库的危险！</font></li>
      <li>官网地址：<font color="#FF0000">http://www.shuipfcms.com</font>，<a href="http://www.shuipfcms.com" target="_blank">立即前往</a>！</li>
    </ul>
  </div>
  <div class="table_list">
    <table width="100%">
      <thead>
        <tr>
          <td width="100">名称</td>
          <td width="100">标识</td>
          <td align="center">描述</td>
          <td align="center" width="50">状态</td>
          <td align="center" width="100">作者</td>
          <td align="center" width="50">版本</td>
          <td align="center" width="227">操作</td>
        </tr>
      </thead>
      <?php if(is_array($addons)): $i = 0; $__LIST__ = $addons;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
        <td><?php if( $vo['url'] ): ?><a  href="<?php echo ($vo["url"]); ?>" target="_blank"><?php echo ($vo["title"]); ?></a><?php else: echo ($vo["title"]); endif; ?></td>
        <td><?php echo ($vo["name"]); ?></td>
        <td><?php echo ($vo["description"]); ?></td>
        <td align="center"><?php if( $vo['status'] == null ): ?>未安装<?php else: if( $vo['status'] == 1 ): ?>启用<?php else: ?>禁用<?php endif; endif; ?></td>
        <td align="center"><?php echo ($vo["author"]); ?></td>
        <td align="center"><?php echo ($vo["version"]); ?></td>
        <td align="center">
          <?php if( $vo['uninstall'] ): ?><a  href="<?php echo U('Addons/install', array('addonename'=>$vo['name']) );?>" class="btn btn_submit btn_big">安装</a>
          <?php else: ?>
          <?php if( $vo['config'] ): ?><a  href="<?php echo U('Addons/config', array('id'=>$vo['id']) );?>" class="btn btn_submit btn_big">设置</a><?php endif; ?>
          <?php if( $vo['status'] ): ?><a  href="<?php echo U('Addons/status', array('id'=>$vo['id']) );?>" class="btn btn_big">禁用</a>
          <?php else: ?>
          <a  href="<?php echo U('Addons/status', array('id'=>$vo['id']) );?>" class="btn btn_big">启用</a><?php endif; ?>
          <a  href="<?php echo U('Addons/uninstall', array('id'=>$vo['id']) );?>" class="btn btn_big">卸载</a><?php endif; ?>
          <a  href="<?php echo U('Addons/unpack', array('addonname'=>$vo['name']) );?>" class="btn btn_big">打包</a>
         </td>
      </tr><?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
  </div>
  <div class="p10">
        <div class="pages"><?php echo ($Page); ?></div>
   </div>
</div>
<script src="<?php echo ($config_siteurl); ?>statics/js/common.js?v"></script>
<script>
if ($('button.J_ajax_upgrade').length) {
    Wind.use('artDialog', function () {
        $('.J_ajax_upgrade').on('click', function (e) {
            e.preventDefault();
           var $_this = this,$this = $(this), url = $this.data('action'), msg = $this.data('msg'), act = $this.data('act');
            art.dialog({
                title: false,
                icon: 'question',
                content: '确定要卸载吗？',
                follow: $_this,
                close: function () {
                    $_this.focus();; //关闭时让触发弹窗的元素获取焦点
                    return true;
                },
                ok: function () {
                    $.getJSON(url).done(function (data) {
                        if (data.state === 'success') {
                            if (data.referer) {
                                location.href = data.referer;
                            } else {
                                reloadPage(window);
                            }
                        } else if (data.state === 'fail') {
                            art.dialog.alert(data.info);
                        }
                    });
                },
                cancelVal: '关闭',
                cancel: true
            });
        });

    });
}
</script>
</body>
</html>