<?php if (!defined('THINK_PATH')) exit(); if (!defined('SHUIPF_VERSION')) exit(); ?>
<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>系统后台 - <?php echo ($Config["sitename"]); ?> - by LvyeCMS</title>
<?php if (!defined('SHUIPF_VERSION')) exit(); ?><link href="<?php echo ($config_siteurl); ?>statics/css/admin_style.css" rel="stylesheet" />
<link href="<?php echo ($config_siteurl); ?>statics/js/artDialog/skins/default.css" rel="stylesheet" />
<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<script type="text/javascript">
//全局变量
var GV = {
    DIMAUB: "<?php echo ($config_siteurl); ?>",
	JS_ROOT: "<?php echo ($config_siteurl); ?>statics/js/"
};
</script>
<script src="<?php echo ($config_siteurl); ?>statics/js/wind.js"></script>
<script src="<?php echo ($config_siteurl); ?>statics/js/jquery.js"></script>
</head>
<body class="J_scroll_fixed">
<div class="wrap">
  <?php  $getMenu = isset($Custom)?$Custom:D('Admin/Menu')->getMenu(); if($getMenu) { ?>
<div class="nav">
  <?php
 if(!empty($menuReturn)){ echo '<div class="return"><a href="'.$menuReturn['url'].'">'.$menuReturn['name'].'</a></div>'; } ?>
  <ul class="cc">
    <?php
 foreach($getMenu as $r){ $app = $r['app']; $controller = $r['controller']; $action = $r['action']; ?>
    <li <?php echo $action==ACTION_NAME ?'class="current"':""; ?>><a href="<?php echo U("".$app."/".$controller."/".$action."",$r['parameter']);?>" <?php echo $r['target']?'target="'.$r['target'].'"':"" ?>><?php echo $r['name'];?></a></li>
    <?php
 } ?>
  </ul>
</div>
<?php } ?>
 <div class="h_a">编辑1广告</div>
  <form action="" method="post" name="myform" class="J_ajaxForm">
  <div class="table_full">
  <table class="table_form" width="100%" cellspacing="0">
  <tbody>
	<tr>
		<th width="150"><strong>广告名称：</strong></th>
		<td><input name="info[title]" id="title" value="<?php echo ($yjz_ad["title"]); ?>" class="input" type="text" size="30"></td>
	</tr>
	<tr>
		<th width="150"><strong>广告位置：</strong></th>
		<td>	<select name="info[type]" id="info[type]" class="selector">
              <option value="1">位置一</option>
			  <option value="2">位置二</option>	
			  <option value="3">位置三</option>
              </select></td>
	</tr>	
	<tr>
		<th><strong>广告地址：</strong></th>
		<td><input name="info[url]" id="url" class="input"  value="<?php echo ($yjz_ad["url"]); ?>"  type="text" size="25"></td>
	</tr>

    <tr>
    <th><strong>广告图：</strong></th>
      <td><?php  echo call_user_func_array(array("\Form","images"),array('0'=>'info[image]','1'=>'image','2'=>'','3'=>'Links',)); ?><span class="gray"> 双击可以查看图片！</span></td>
    </tr>
	<tr>
		<th><strong>是否启用：</strong></th>
		<td><label><input type="radio" name="info[status]" <?php if($yjz_ad[status] == 1): ?>checked='checked'<?php endif; ?> value="1"> 启用</label> <label><input type="radio" name="info[status]" value="0" <?php if($yjz_ad[status] == 0): ?>checked='checked'<?php endif; ?>> 不启用</label></td>
	</tr>	
	</tbody>
</table>
</div>
  <div class="btn_wrap">
      <div class="btn_wrap_pd">
         <input name="info[id]" id="id" class="input"  value="<?php echo ($yjz_ad["id"]); ?>"  type="hidden" size="25">  
        <button class="btn btn_submit mr10 J_ajax_submit_btn" type="submit">提交</button>
      </div>
    </div>
<script src="<?php echo ($config_siteurl); ?>statics/js/common.js?v"></script>
<script type="text/javascript" src="<?php echo ($config_siteurl); ?>statics/js/content_addtop.js"></script>
<script>
$(function(){
	$('#image').val('<?php echo ($yjz_ad["image"]); ?>');
	$(".selector").val('<?php echo ($yjz_ad["type"]); ?>').attr("selected",true);; 
});
</script>
</body>
</html>