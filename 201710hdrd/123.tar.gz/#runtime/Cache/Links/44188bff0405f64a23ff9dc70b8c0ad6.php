<?php if (!defined('THINK_PATH')) exit(); if (!defined('SHUIPF_VERSION')) exit(); ?>
<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>系统后台 - <?php echo ($Config["sitename"]); ?> - by LvyeCMS</title>
<?php if (!defined('SHUIPF_VERSION')) exit(); ?><link href="<?php echo ($config_siteurl); ?>statics/css/admin_style.css" rel="stylesheet" />
<link href="<?php echo ($config_siteurl); ?>statics/js/artDialog/skins/default.css" rel="stylesheet" />
<?php if (!defined('SHUIPF_VERSION')) exit(); ?>
<script type="text/javascript">
//全局变量
var GV = {
    DIMAUB: "<?php echo ($config_siteurl); ?>",
	JS_ROOT: "<?php echo ($config_siteurl); ?>statics/js/"
};
</script>
<script src="<?php echo ($config_siteurl); ?>statics/js/wind.js"></script>
<script src="<?php echo ($config_siteurl); ?>statics/js/jquery.js"></script>
</head>
<body class="J_scroll_fixed">
<div class="wrap J_check_wrap">
  <?php  $getMenu = isset($Custom)?$Custom:D('Admin/Menu')->getMenu(); if($getMenu) { ?>
<div class="nav">
  <?php
 if(!empty($menuReturn)){ echo '<div class="return"><a href="'.$menuReturn['url'].'">'.$menuReturn['name'].'</a></div>'; } ?>
  <ul class="cc">
    <?php
 foreach($getMenu as $r){ $app = $r['app']; $controller = $r['controller']; $action = $r['action']; ?>
    <li <?php echo $action==ACTION_NAME ?'class="current"':""; ?>><a href="<?php echo U("".$app."/".$controller."/".$action."",$r['parameter']);?>" <?php echo $r['target']?'target="'.$r['target'].'"':"" ?>><?php echo $r['name'];?></a></li>
    <?php
 } ?>
  </ul>
</div>
<?php } ?>
  <div class="h_a">链接详情</div>
  <form name="myform" action="<?php echo U('Links/edit');?>" method="post" class="J_ajaxForm">
  <div class="table_full">
  <table width="100%" class="table_form contentWrap">
        <tbody>
        <tr>
          <th width="200">链接名称</th>
          <td><input type="text" name="name" value="<?php echo ($name); ?>" class="input" id="name" size="30"></td>
        </tr>
        <tr>
          <th>地址</th>
          <td><input type="text" name="url" value="<?php echo ($url); ?>" class="input" id="url" size="30" style=" width:300px;"></td>
        </tr>
        <tr>
          <th>所属分类</th>
          <td>
          <select name="termsid">
            <option value="">==分类选择==</option>
            <?php if(is_array($Terms)): $i = 0; $__LIST__ = $Terms;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>" <?php if( $vo[id] == $termsid ): ?>selected<?php endif; ?>><?php echo ($vo["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
          </select> 创建新分类：<input type="text" name="terms[name]" value="" class="input" size="30"></td>
        </tr>
        <tr>
          <th>Logo</th>
          <td><?php echo Form::images('image', 'image', $image , 'links');?></td>
        </tr>
        <tr>
          <th>打开方式</th>
          <td>
          <select name="target">
            <option value="_self" <?php if( $target == '_self' ): ?>selected<?php endif; ?>>默认打开方式</option>
            <option value="_blank" <?php if( $target == '_blank' ): ?>selected<?php endif; ?>>新窗口打开</option>
          </select></td>
        </tr>
        <tr>
          <th>链接是否可见</th>
          <td>
          <select name="visible">
            <option value="1" <?php if( $visible == '1' ): ?>selected<?php endif; ?>>可见</option>
            <option value="0" <?php if( $visible == '0' ): ?>selected<?php endif; ?>>不可见</option>
          </select></td>
        </tr>
        <tr>
          <th>RSS地址</th>
          <td><input type="text" name="rss" value="<?php echo ($rss); ?>" class="input" id="rss" size="30" style=" width:300px;"></td>
        </tr>
        <tr>
          <th>链接描述</th>
          <td><textarea name="description" rows="2" cols="20" id="description" class="inputtext" style="height:100px;width:500px;"><?php echo ($description); ?></textarea></td>
        </tr>
        <tr>
          <th>链接详细介绍</th>
          <td><textarea name="notes" rows="2" cols="20" id="notes" class="inputtext" style="width:700px;"><?php echo ($notes); ?></textarea></td>
        </tr>
      </tbody>
      </table>
  </div>
  <div class="btn_wrap">
      <div class="btn_wrap_pd">             
        <button class="btn btn_submit mr10 J_ajax_submit_btn" type="submit">提交</button>
        <input name="id" type="hidden" value="<?php echo ($id); ?>" />
      </div>
    </div>
  </form>
</div>
<script src="<?php echo ($config_siteurl); ?>statics/js/common.js?v"></script>
<script type="text/javascript" src="<?php echo ($config_siteurl); ?>statics/js/content_addtop.js"></script>

</body>
</html>