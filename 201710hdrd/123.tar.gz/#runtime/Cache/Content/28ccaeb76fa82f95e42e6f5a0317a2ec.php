<?php if (!defined('THINK_PATH')) exit();?><input type="hidden" name="info[relation]" id="relation" value="" style="50" >
<ul class="list-dot" id="relation_text">
</ul>
<input type="button" value="添加相关" onClick="omnipotent('selectid',GV.DIMAUB+'index.php?a=public_relationlist&m=Content&g=Content&modelid=1','添加相关文章',1)" class="btn">
<span class="edit_content">
  <input type="button" value="显示已有" onClick="show_relation(1,3)" class="btn">
</span>