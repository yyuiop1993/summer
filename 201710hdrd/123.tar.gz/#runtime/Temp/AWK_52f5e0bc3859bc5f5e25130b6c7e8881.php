<?php
//000000000000a:1:{i:1;a:7:{s:5:"posid";s:1:"1";s:7:"modelid";s:1:"0";s:5:"catid";s:20:"21,16,17,18,19,20,30";s:4:"name";s:6:"推荐";s:6:"maxnum";s:3:"100";s:9:"extention";s:0:"";s:9:"listorder";s:1:"0";}}
?>