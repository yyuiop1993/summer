<?php
//000000000000a:9:{s:7:"modelid";a:1:{i:0;s:1:"1";}s:13:"relationenble";s:1:"1";s:7:"segment";s:1:"1";s:9:"dzsegment";b:0;s:8:"pagesize";s:2:"10";s:9:"cachetime";s:1:"0";s:12:"sphinxenable";s:1:"0";s:10:"sphinxhost";s:0:"";s:10:"sphinxport";s:0:"";}
?>