<?php
//000000000000a:1:{s:2:"Ad";a:11:{s:2:"id";s:1:"1";s:4:"name";s:2:"Ad";s:4:"sign";s:32:"0506d7a6edf46e871bc4e91494c300a2";s:5:"title";s:12:"广告管理";s:11:"description";s:27:"一个基本的广告管理";s:6:"status";s:1:"1";s:6:"config";s:0:"";s:6:"author";s:9:"缪汶臻";s:7:"version";s:3:"1.0";s:11:"create_time";s:1:"0";s:13:"has_adminlist";s:1:"1";}}
?>